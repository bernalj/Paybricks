# Paybricks
This extension removes the paywall on popular Spanish newspapers, allowing you to read the news without having to register.

# Install
1. Download the .zip
2. Extract the contents of the zip file
3. In Chrome, click on the tree dots in the top right of the browser, then click "More tools" then click "Extensions".
4. Turn on the switch on the top right of the page that says "Developer mode"
5. Click on the button on the top left of the page that says "Load unpacked".
6. Select the folder where you extracted the contents of the Zip file
